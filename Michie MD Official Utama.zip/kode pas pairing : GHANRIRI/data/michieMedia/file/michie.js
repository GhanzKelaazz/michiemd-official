{
	"name": "michie Bot Multi Device "
}